# Database Identity Lock — Premieros/55

## Canonical project identity

This repository is bound to exactly one Supabase project unless the user explicitly approves a database migration:

- Repository: `Premieros/55`
- Supabase project ref: `scpovyrqmsbiduanykod`
- Supabase project URL: `https://scpovyrqmsbiduanykod.supabase.co`

## Non-negotiable rule

Application code, CI/deployment workflows, tests, environment files and operational database scripts must not point to any other remote Supabase project. Any other remote project ref or URL is a hard failure.

Localhost/127.0.0.1 database URLs remain allowed only for isolated local/CI tests.

## Enforcement

`scripts/db/verify-database-identity.js` enforces the canonical identity and rejects a different `SUPABASE_PROJECT_REF`, `VITE_SUPABASE_URL`, or remote `SUPABASE_DB_URL`.

## Change control

Changing the database identity requires an explicit user instruction and coordinated updates to this lock, CI/deployment configuration, tests and migration tooling.
