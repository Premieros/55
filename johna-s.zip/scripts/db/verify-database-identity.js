const EXPECTED_PROJECT_REF = 'scpovyrqmsbiduanykod'
const EXPECTED_URL = `https://${EXPECTED_PROJECT_REF}.supabase.co`

const configuredRef = (process.env.SUPABASE_PROJECT_REF || EXPECTED_PROJECT_REF).trim()
const configuredUrl = (process.env.VITE_SUPABASE_URL || EXPECTED_URL).trim().replace(/\/$/, '')

function fail(message) {
  console.error(`DATABASE_IDENTITY_LOCK_FAILED: ${message}`)
  process.exit(1)
}

if (configuredRef !== EXPECTED_PROJECT_REF) {
  fail(`SUPABASE_PROJECT_REF must be ${EXPECTED_PROJECT_REF}, received ${configuredRef || '<empty>'}`)
}

let parsed
try {
  parsed = new URL(configuredUrl)
} catch {
  fail('VITE_SUPABASE_URL is not a valid URL')
}

if (parsed.protocol !== 'https:' || parsed.hostname !== `${EXPECTED_PROJECT_REF}.supabase.co`) {
  fail(`VITE_SUPABASE_URL must be ${EXPECTED_URL}`)
}

const dbUrl = (process.env.SUPABASE_DB_URL || '').trim()
if (dbUrl && !/localhost|127\.0\.0\.1/.test(dbUrl)) {
  let dbHost = ''
  try {
    dbHost = new URL(dbUrl).hostname
  } catch {
    fail('SUPABASE_DB_URL is not a valid database URL')
  }
  const directHost = `db.${EXPECTED_PROJECT_REF}.supabase.co`
  const isDirect = dbHost === directHost
  const isPooler = dbHost.endsWith('.pooler.supabase.com') && dbUrl.includes(EXPECTED_PROJECT_REF)
  if (!isDirect && !isPooler) {
    fail(`SUPABASE_DB_URL does not belong to ${EXPECTED_PROJECT_REF}`)
  }
}

console.log(`Database identity verified: ${EXPECTED_PROJECT_REF}`)
