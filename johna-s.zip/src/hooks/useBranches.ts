import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/api';
import { useAuth } from '@/context/AuthContext';
import type { Branch } from '@/lib/types';

const BRANCHES_CHANGED_EVENT = 'premier:branches-changed';
const branchCacheByUser = new Map<string, Branch[]>();

export function notifyBranchesChanged(): void {
  branchCacheByUser.clear();
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event(BRANCHES_CHANGED_EVENT));
  }
}

export function useBranches() {
  const { user } = useAuth();
  const userId = user?.id ?? null;
  const cached = userId ? branchCacheByUser.get(userId) : undefined;
  const [branches, setBranches] = useState<Branch[]>(cached ?? []);
  const [loading, setLoading] = useState(Boolean(userId) && cached === undefined);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!userId) {
      setBranches([]);
      setError(null);
      setLoading(false);
      return;
    }

    setLoading(branchCacheByUser.get(userId) === undefined);
    const { data, error } = await supabase.from('branches').select('*').order('name');
    if (error) {
      setBranches([]);
      setError(error.message);
      setLoading(false);
      return;
    }

    const next = (data as Branch[]) || [];
    branchCacheByUser.set(userId, next);
    setBranches(next);
    setError(null);
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    if (!userId) {
      setBranches([]);
      setLoading(false);
      setError(null);
      return;
    }

    const sessionCached = branchCacheByUser.get(userId);
    if (sessionCached !== undefined) {
      setBranches(sessionCached);
      setLoading(false);
      setError(null);
    } else {
      void refresh();
    }

    if (typeof window === 'undefined') return;
    const onBranchesChanged = () => {
      branchCacheByUser.delete(userId);
      void refresh();
    };
    window.addEventListener(BRANCHES_CHANGED_EVENT, onBranchesChanged);
    return () => window.removeEventListener(BRANCHES_CHANGED_EVENT, onBranchesChanged);
  }, [refresh, userId]);

  return { branches, loading, error, refresh };
}
