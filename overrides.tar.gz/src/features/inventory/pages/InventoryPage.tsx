import { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, Download, Edit2 } from 'lucide-react';
import { supabase } from '@/api';
import * as api from '@/api';
import { useLanguage } from '@/context/LanguageContext';
import { useToast } from '@/components/Toast';
import { useCan } from '@/lib/permissions';
import { DesignSurface, DesignPageHeader, DesignSearch, DesignPanel, DesignPagination } from '@/components/design';
import { DataTable, type Column } from '@/components/DataTable';
import { Button } from '@/components/Button';
import { Input, Select } from '@/components/Input';
import { Modal } from '@/components/Modal';
import { BranchBadge } from '@/components/BranchBadge';
import { formatNumber } from '@/lib/format';
import { exportToExcel } from '@/lib/excel';
import { logAudit } from '@/lib/audit';
import { usePaginatedRows } from '@/hooks/usePaginatedRows';
import { useBranches } from '@/hooks/useBranches';
import type { Inventory, Warehouse, RawMaterial } from '@/lib/types';

type RawWarehouseStock = {
  id: string;
  raw_material_id: string;
  branch_id: string;
  warehouse_id: string;
  quantity: number;
  avg_cost: number;
  updated_at: string;
  raw_material?: RawMaterial;
  warehouse?: Warehouse;
};

type InventoryRow =
  | { kind: 'product'; inventory: Inventory }
  | { kind: 'raw'; inventory: RawWarehouseStock };

export function InventoryPage() {
  const { t, lang } = useLanguage();
  const isAr = lang === 'ar';
  const { show } = useToast();
  const can = useCan();
  const { branches } = useBranches();
  const { rows: items, loading, error, total, hasMore, loadMore, loadingMore, refresh: reloadInventory } = usePaginatedRows<Inventory>({
    table: 'inventory',
    select: '*, product:products(*), warehouse:warehouses(*)',
    order: { column: 'updated_at', ascending: false },
    pageSize: 100,
  });

  const [rawStock, setRawStock] = useState<RawWarehouseStock[]>([]);
  const [rawLoading, setRawLoading] = useState(true);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [componentIds, setComponentIds] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState('');
  const [filterWarehouse, setFilterWarehouse] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'ready' | 'components' | 'raw'>('all');
  const [adjustModal, setAdjustModal] = useState<InventoryRow | null>(null);
  const [adjustQty, setAdjustQty] = useState(0);
  const [adjustReason, setAdjustReason] = useState('');

  const reloadRaw = async () => {
    setRawLoading(true);
    try {
      const { data, error: rawError } = await supabase
        .from('raw_material_warehouse_inventory')
        .select('*, raw_material:raw_materials(*), warehouse:warehouses(*)')
        .order('updated_at', { ascending: false });
      if (rawError) {
        show(rawError.message, 'error');
        setRawStock([]);
      } else {
        setRawStock((data as RawWarehouseStock[]) || []);
      }
    } finally {
      setRawLoading(false);
    }
  };

  useEffect(() => {
    async function loadMeta() {
      const [wh, pc] = await Promise.all([
        supabase.from('warehouses').select('*').order('name'),
        supabase.from('product_components').select('component_product_id'),
      ]);
      setWarehouses((wh.data as Warehouse[]) || []);
      setComponentIds(new Set((pc.data || []).map((row: { component_product_id: string }) => row.component_product_id)));
    }
    void loadMeta();
    void reloadRaw();
  }, []);

  const rows = useMemo<InventoryRow[]>(
    () => [
      ...items.map((inventory) => ({ kind: 'product' as const, inventory })),
      ...rawStock.map((inventory) => ({ kind: 'raw' as const, inventory })),
    ],
    [items, rawStock],
  );

  const filtered = rows.filter((row) => {
    const warehouseId = row.inventory.warehouse_id;
    if (filterWarehouse && warehouseId !== filterWarehouse) return false;

    if (row.kind === 'raw') {
      if (filterType !== 'all' && filterType !== 'raw') return false;
      if (!search) return true;
      const q = search.toLocaleLowerCase();
      return row.inventory.raw_material?.name?.toLocaleLowerCase().includes(q)
        || row.inventory.raw_material?.code?.toLocaleLowerCase().includes(q);
    }

    const item = row.inventory;
    if (filterType === 'raw') return false;
    if (filterType === 'components' && !componentIds.has(item.product_id)) return false;
    if (filterType === 'ready' && componentIds.has(item.product_id)) return false;
    if (!search) return true;
    const query = search.toLocaleLowerCase();
    return item.product?.name.toLocaleLowerCase().includes(query) || item.product?.barcode?.includes(search);
  });

  const openAdjust = (row: InventoryRow) => {
    if (!can('inventory.adjust')) return;
    setAdjustModal(row);
    setAdjustQty(Number(row.inventory.quantity));
    setAdjustReason('');
  };

  const saveAdjust = async () => {
    if (!adjustModal || !can('inventory.adjust')) return;
    if (!adjustReason.trim()) {
      show(isAr ? 'سبب التسوية مطلوب' : 'Adjustment reason is required', 'error');
      return;
    }

    if (adjustModal.kind === 'product') {
      const inventory = adjustModal.inventory;
      const { data, error: adjustError } = await api.inventory.adjustStock({
        p_inventory_id: inventory.id,
        p_new_quantity: adjustQty,
        p_reason: adjustReason.trim(),
      });
      if (adjustError) { show(adjustError.message, 'error'); return; }
      const result = data as { success: boolean; error?: string; detail?: string } | null;
      if (!result?.success) { show(result?.detail || result?.error || t('error'), 'error'); return; }
      await logAudit('update', 'inventory', inventory.id, { from: inventory.quantity, to: adjustQty, reason: adjustReason.trim() });
      reloadInventory();
    } else {
      const inventory = adjustModal.inventory;
      const { data, error: adjustError } = await api.inventory.adjustRawStock({
        p_raw_material_id: inventory.raw_material_id,
        p_branch_id: inventory.branch_id,
        p_warehouse_id: inventory.warehouse_id,
        p_new_quantity: adjustQty,
        p_reason: adjustReason.trim(),
      });
      if (adjustError) { show(adjustError.message, 'error'); return; }
      const result = data as { success: boolean; error?: string; detail?: string } | null;
      if (!result?.success) { show(result?.detail || result?.error || t('error'), 'error'); return; }
      await logAudit('update', 'raw_material_warehouse_inventory', inventory.id, {
        from: inventory.quantity,
        to: adjustQty,
        reason: adjustReason.trim(),
        warehouse_id: inventory.warehouse_id,
      });
      await reloadRaw();
    }

    show(t('saveSuccess'), 'success');
    setAdjustModal(null);
  };

  const nameOf = (row: InventoryRow) =>
    row.kind === 'product' ? (row.inventory.product?.name || '-') : (row.inventory.raw_material?.name || '-');

  const warehouseOf = (row: InventoryRow) => row.inventory.warehouse?.name || '-';

  const branchIdOf = (row: InventoryRow) =>
    row.kind === 'product' ? row.inventory.warehouse?.branch_id : row.inventory.branch_id;

  const typeOf = (row: InventoryRow) => {
    if (row.kind === 'raw') return isAr ? 'مادة خام' : 'Raw material';
    if (componentIds.has(row.inventory.product_id)) return isAr ? 'مكوّن منتج' : 'Product component';
    return isAr ? 'منتج' : 'Product';
  };

  const thresholdOf = (row: InventoryRow) =>
    row.kind === 'product'
      ? Number(row.inventory.product?.low_stock_threshold || 0)
      : Number(row.inventory.raw_material?.min_stock || 0);

  const handleExport = () => {
    exportToExcel(filtered.map((row) => ({
      Type: typeOf(row),
      Item: nameOf(row),
      Warehouse: warehouseOf(row),
      Branch: branches.find((branch) => branch.id === branchIdOf(row))?.name || '',
      Quantity: Number(row.inventory.quantity),
      LowStockThreshold: thresholdOf(row),
    })), 'inventory');
  };

  const columns: Column<InventoryRow>[] = [
    { key: 'item', header: isAr ? 'الصنف' : 'Item', render: (row) => (
      <div className="flex items-center gap-2">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-ui-page-alt text-xs font-bold text-ui-subtle">{nameOf(row)[0] || '?'}</div>
        <div>
          <p className="font-medium text-ui-text">{nameOf(row)}</p>
          <p className="text-xs text-ui-subtle">{typeOf(row)}</p>
        </div>
      </div>
    )},
    { key: 'warehouse', header: t('warehouse'), render: warehouseOf },
    { key: 'branch', header: t('branch'), render: (row) => (
      <BranchBadge name={branches.find((branch) => branch.id === branchIdOf(row))?.name || '-'} />
    )},
    { key: 'quantity', header: t('quantity'), render: (row) => {
      const quantity = Number(row.inventory.quantity);
      const low = quantity < thresholdOf(row);
      return (
        <div className="flex items-center gap-2">
          <span className={`font-semibold ${low ? 'text-ui-danger' : 'text-ui-text'}`}>{formatNumber(quantity)}</span>
          {low && <AlertTriangle className="h-4 w-4 text-ui-warning" />}
        </div>
      );
    }},
    { key: 'status', header: t('status'), render: (row) => {
      const quantity = Number(row.inventory.quantity);
      const low = quantity < thresholdOf(row);
      const out = quantity <= 0;
      return <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${out ? 'bg-ui-danger-soft text-ui-danger' : low ? 'bg-ui-warning-soft text-ui-warning' : 'bg-ui-success-soft text-ui-success'}`}>{out ? t('outOfStock') : low ? t('lowStock') : t('inStock')}</span>;
    }},
    { key: 'actions', header: t('actions'), render: (row) => can('inventory.adjust') ? (
      <button onClick={(event) => { event.stopPropagation(); openAdjust(row); }} className="rounded-md p-1.5 text-ui-info hover:bg-ui-info-soft" title={t('adjustStock')}><Edit2 className="h-4 w-4" /></button>
    ) : null },
  ];

  return (
    <DesignSurface testId="inventory-page">
      <DesignPageHeader title={t('inventory')} actions={<Button variant="outline" size="sm" onClick={handleExport}><Download className="h-4 w-4" /> {t('exportExcel')}</Button>} />
      <DesignPanel testId="inventory-search-panel">
        <div className="flex flex-col gap-3 sm:flex-row">
          <DesignSearch value={search} onChange={setSearch} className="flex-1" label={t('search')} placeholder={t('search')} testId="inventory-search" />
          <Select value={filterWarehouse} onChange={(event) => setFilterWarehouse(event.target.value)} className="sm:w-48">
            <option value="">{t('all')} - {t('warehouses')}</option>
            {warehouses.map((warehouse) => <option key={warehouse.id} value={warehouse.id}>{warehouse.name}</option>)}
          </Select>
          <Select value={filterType} onChange={(event) => setFilterType(event.target.value as typeof filterType)} className="sm:w-44">
            <option value="all">{t('all')}</option>
            <option value="ready">{isAr ? 'منتج' : 'Product'}</option>
            <option value="components">{isAr ? 'مكوّن منتج' : 'Product component'}</option>
            <option value="raw">{isAr ? 'مادة خام' : 'Raw material'}</option>
          </Select>
        </div>
      </DesignPanel>
      <DesignPanel testId="inventory-table-panel">
        <DataTable columns={columns} data={filtered} loading={loading || rawLoading} error={error} emptyMessage={t('noData')} onRowClick={can('inventory.adjust') ? openAdjust : undefined} />
        <DesignPagination loaded={items.length} total={total} hasMore={hasMore} loadingMore={loadingMore} onLoadMore={loadMore} />
      </DesignPanel>

      <Modal open={!!adjustModal} onClose={() => setAdjustModal(null)} title={t('adjustStock')} size="sm">
        {adjustModal && <div className="space-y-4">
          <div><p className="text-sm text-ui-subtle">{isAr ? 'الصنف' : 'Item'}</p><p className="font-medium text-ui-text">{nameOf(adjustModal)}</p></div>
          <div><p className="text-sm text-ui-subtle">{t('warehouse')}</p><p className="font-medium text-ui-text">{warehouseOf(adjustModal)}</p></div>
          <Input label={t('currentStock')} type="number" step="0.0001" value={adjustQty} onChange={(event) => setAdjustQty(parseFloat(event.target.value) || 0)} />
          <Input label={t('reason')} value={adjustReason} onChange={(event) => setAdjustReason(event.target.value)} placeholder={isAr ? 'مثال: جرد، تالف، تصحيح' : 'e.g. count, damaged, correction'} required />
          <div className="flex justify-end gap-2"><Button variant="secondary" onClick={() => setAdjustModal(null)}>{t('cancel')}</Button><Button onClick={saveAdjust}>{t('save')}</Button></div>
        </div>}
      </Modal>
    </DesignSurface>
  );
}
